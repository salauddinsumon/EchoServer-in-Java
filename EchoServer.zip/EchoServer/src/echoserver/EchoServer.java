
package echoserver;
import java.net.*;
import java.io.*;



public class EchoServer {
    final static int thePort = 1234;
    ServerSocket theServerSocket;

    
    public static void main(String[] args) {
        EchoServer theApp = new EchoServer();
        theApp.run();
    }
    Public EchoServer()
    {
        try{
            theServerSocket(thePort);
        }
        catch(IOException io)
        {
            System.err.println("Socket Error: terminating");
            System.exit(1);
        }
    }
    public void run()
    {
        try 
        {
            System.out.println("Server Ready");
            Socket theSocket= theServerSocket.accept();
            System.out.println("Client connected");
            BufferReader in = new BufferReader(new InputStream Reader(theSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(theSocket.getOutputStream()),true);
            while(true)
            {
                String line= in.readLine();
                if(line==null)
                    break;
                System.out.println("Read:"+line);
                line= line.toUpperCase()+"!";
                out.println(line);
                System.out.println("Wrote"+line);
            }
        }   in.close();
            out.close();
            theSocket.close();
            System.exit(0);
            
    }
    catch(IOException io)
    {
        System.err.println("Socket Error terminating");
        System.exit(1);
    }
}
